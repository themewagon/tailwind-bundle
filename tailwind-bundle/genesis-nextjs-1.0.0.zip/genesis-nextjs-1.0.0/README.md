# Genesis – AI Agent SaaS Template
#### Preview

 - [Demo](https://themewagon.github.io/genesis-nextjs/)

#### Download
 - [Download from ThemeWagon](https://themewagon.com/themes/genesis-nextjs/)

## Getting Started

1. Clone Repository
```
git clone https://github.com/themewagon/genesis-nextjs.git
```
2. Install Dependencies
```
npm i
```
3. Run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

## Author 
```
Design and code is completely written by PrebuiltUI and development team. 
```

## License

 - Design and Code is Copyright &copy; <a href="https://prebuiltui.com/?utm_source=genesis" target="_blank">PrebuiltUI</a>
 - Licensed cover under [MIT]
 - Distributed by <a href="https://themewagon.com" target="_blank">ThemeWagon</a>

