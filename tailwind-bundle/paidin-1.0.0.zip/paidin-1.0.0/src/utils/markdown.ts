import fs from "fs";
import matter from "gray-matter";
import { join } from "path";
import { Blog } from "@/types/blog";

const postsDirectory = join(process.cwd(), "markdown/Blog");

export function getPostSlugs() {
    return fs.readdirSync(postsDirectory);
}

export function getPostBySlug(slug: string, fields: string[] = []): Partial<Blog> {
    const realSlug = slug.replace(/\.mdx$/, "");
    const fullPath = join(postsDirectory, `${realSlug}.mdx`);
    const fileContents = fs.readFileSync(fullPath, "utf8");
    const { data, content } = matter(fileContents);

    type Items = Record<string, string | object>;

    const items: Items = {};

    function processImages(content: string): string {
        // You can modify this function to handle image processing
        // For example, replace image paths with actual HTML image tags
        return content.replace(/!\[.*?\]\((.*?)\)/g, '<img src="$1" alt="" />');
    }

    // Ensure only the minimal needed data is exposed
    fields.forEach((field) => {
        if (field === "slug") {
            items[field] = realSlug;
        }
        if (field === "content") {
            // You can modify the content here to include Images
            items[field] = processImages(content);
        }

        if (field === "metadata") {
            // Include metadata, including the image information
            items[field] = { ...data, coverImage: data.coverImage || null };
        }

        if (typeof data[field] !== "undefined") {
            items[field] = data[field];
        }
    });

    return items as Partial<Blog>;
}

export function getAllPosts(fields: string[] = []): Partial<Blog>[] {
    const slugs = getPostSlugs();
    const posts = slugs
        .map((slug) => getPostBySlug(slug, fields))
        // sort posts by date in descending order
        .sort((post1, post2) => {
            const date1 = post1.date || "";
            const date2 = post2.date || "";
            return date1 > date2 ? -1 : 1;
        });

    return posts;
}
